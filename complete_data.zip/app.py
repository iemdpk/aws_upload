from flask import Flask,render_template,request
app = Flask(__name__)
import json
import requests;

@app.route('/')
def hello_world():
    response_api = requests.get('http://api.serpstack.com/search?access_key=80eabc9d204b2a62ada03784e91a11e3&query=Gta 5');
    return render_template('engine.html',data=response_api.json()["organic_results"])


@app.route('/search',methods=['GET'])
def search():
    if request.method == "GET":
        data = request.args.get("query");
        response_api = requests.get('http://api.serpstack.com/search?access_key=80eabc9d204b2a62ada03784e91a11e3&query='+data);
        
        return render_template('showData.html',data=response_api.json()["organic_results"])